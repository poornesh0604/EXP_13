from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'small_finance'
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/customers')
def customers():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM customers")
    customers = cursor.fetchall()
    conn.close()
    return render_template('customers.html', customers=customers)

@app.route('/calculate-emi')
def calculate_emi():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.callproc('calculate_gold_loan_emi')
    conn.commit()
    conn.close()
    return "EMI calculation complete."

if __name__ == '__main__':
    app.run(debug=True)