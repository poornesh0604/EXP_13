# Small Finance Corp App

Run with `python app.py` after setting up MySQL with `small_finance_corp.sql`.